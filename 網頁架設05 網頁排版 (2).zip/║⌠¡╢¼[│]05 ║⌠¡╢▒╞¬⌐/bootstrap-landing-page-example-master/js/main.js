
// 初始化 wow 套件
new WOW().init();

// 網頁的主程式寫在這裡
var typed = new Typed('#title', {
  // 陣列Array[A,B,C,D]
  strings: [
    'Hello everyone',
    'Welcome to me website!',
    'My name is Tim',
  ],
  typeSpeed: 50,
});

new Typed("#subtitle", {
  strings: [
    '大家好!!',
    '歡迎來到我的網站',
    '我的名字是Tim',
  ]
});

var dd = document.querySelector('#dd')

function goTo() {
  dd.scrollIntoView(x - coord, y - coord)
}

// 綁定 .ad-toggle-btn 的點擊事件
$(".ad-toggle-btn").click(function () {
  console.log("[.ad-toggle-btn被點擊了]");

});

// 綁定 #removeSideBoxBtn 的點擊事件
$("#removeSideBoxBtn").click(function () {
  console.log("[#removeSideBoxBtn被點擊了]")

});

// 取得現在的年份
const year = new Date().getFullYear();
// 將年份顯示在 id="yearShow" 的元素內
$("#yearShow").text(year);